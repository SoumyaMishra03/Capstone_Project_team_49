import cv2
import os
import numpy as np

# Input folder containing crime videos
video_folder = r"C:\Users\Shreyas S\OneDrive\Documents\capstone\dataset"
# Output folder to save motion vectors
output_folder = r"C:\Users\Shreyas S\OneDrive\Documents\capstone\optical_flow_data"

# Create output folder if it doesn’t exist
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# Target resolution and FPS
target_width = 640
target_height = 480
target_fps = 30

# List all video files in the directory
video_files = [f for f in os.listdir(video_folder) if f.endswith(('.mp4', '.avi', '.mov'))]

# Process each video
for video_file in video_files:
    video_path = os.path.join(video_folder, video_file)
    cap = cv2.VideoCapture(video_path)

    # Get video properties
    original_fps = int(cap.get(cv2.CAP_PROP_FPS))
    original_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    original_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    print(f"Processing {video_file}: Original FPS={original_fps}, Resolution={original_width}x{original_height}")

    # Read the first frame
    ret, prev_frame = cap.read()
    if not ret:
        print(f"Error reading {video_file}, skipping...")
        cap.release()
        continue

    # Convert first frame to grayscale and resize
    prev_frame = cv2.resize(prev_frame, (target_width, target_height))
    prev_gray = cv2.cvtColor(prev_frame, cv2.COLOR_BGR2GRAY)

    # Storage for Optical Flow motion vectors
    motion_vectors = []
    frame_count = 0

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break  # Stop if video ends

        # Resize and convert current frame to grayscale
        frame = cv2.resize(frame, (target_width, target_height))
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Compute Optical Flow (Farneback Method)
        flow = cv2.calcOpticalFlowFarneback(prev_gray, gray, None, 0.5, 3, 15, 3, 5, 1.2, 0)

        # Store motion vectors
        motion_vectors.append(flow)

        # Update previous frame
        prev_gray = gray
        frame_count +=1

    cap.release()

    # Save motion vectors as a NumPy file (compressed format)
    optical_flow_file = os.path.join(output_folder, f"{os.path.splitext(video_file)[0]}_flow.npy")
    np.save(optical_flow_file, np.array(motion_vectors, dtype=np.float32))

    print(f"Saved Optical Flow data for {video_file} at {optical_flow_file}")
    print(f"Processed {frame_count} frames.")