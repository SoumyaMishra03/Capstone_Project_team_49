import cv2
import numpy as np
import os

# Folder containing processed motion vectors
optical_flow_folder = r"C:\Users\Shreyas S\OneDrive\Documents\capstone\optical_flow_data"
# Folder containing original crime videos
video_folder = r"C:\Users\Shreyas S\OneDrive\Documents\capstone\dataset"

# Get all processed Optical Flow files
optical_flow_files = [f for f in os.listdir(optical_flow_folder) if f.endswith('.npy')]

for flow_file in optical_flow_files:
    video_name = flow_file.replace("_flow.npy", ".mp4")  # Assuming original videos are .mp4
    video_path = os.path.join(video_folder, video_name)

    # Load the original video to overlay motion vectors
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"Error: Could not open video {video_name}")
        continue

    # Load the Optical Flow data
    flow_data = np.load(os.path.join(optical_flow_folder, flow_file))

    # Video properties
    fps = int(cap.get(cv2.CAP_PROP_FPS))
    frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    # Define output video writer
    output_video_path = os.path.join("visualized_optical_flow", f"{video_name}_optical_flow.mp4")
    os.makedirs("visualized_optical_flow", exist_ok=True)
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')  
    out = cv2.VideoWriter(output_video_path, fourcc, fps, (frame_width, frame_height))

    frame_idx = 0
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret or frame_idx >= len(flow_data):
            break

        # Convert Optical Flow data into color visualization
        flow = flow_data[frame_idx]
        hsv = np.zeros_like(frame)
        hsv[..., 1] = 255  # Set saturation to max for color

        # Compute Optical Flow Magnitude & Angle
        mag, ang = cv2.cartToPolar(flow[..., 0], flow[..., 1])

        # Set HSV channels: Hue = direction, Value = magnitude
        hsv[..., 0] = ang * 180 / np.pi / 2  # Normalize angle to 0-180
        hsv[..., 2] = cv2.normalize(mag, None, 0, 255, cv2.NORM_MINMAX)  # Normalize magnitude

        # Convert HSV to BGR for display
        optical_flow_vis = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)

        # Overlay motion vectors on the original frame
        blended = cv2.addWeighted(frame, 0.7, optical_flow_vis, 0.3, 0)

        # Write to output video
        out.write(blended)

        # Show the visualized frame (Press 'q' to quit)
        cv2.imshow("Optical Flow Visualization", blended)
        if cv2.waitKey(10) & 0xFF == ord('q'):
            break

        frame_idx += 1

    cap.release()
    out.release()
    print(f"Saved Optical Flow visualization: {output_video_path}")

cv2.destroyAllWindows()