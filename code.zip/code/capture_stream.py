import cv2

rtsp_url = "rtsp://localhost:8554/live"
cap = cv2.VideoCapture(rtsp_url)

while True:
    ret, frame = cap.read()
    if not ret:
        print("Failed to retrieve frame")
        break

    cv2.imshow("RTSP Stream", frame)
    
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
